import os
import string
import json
import datetime
import random
import requests
from flask import Flask, request, render_template
import manager
from manager import generate_html_report

app = Flask(__name__)
filename = os.path.join(os.path.dirname(__file__), 'C:\\Users\\Алина\\Desktop\\учеба\\СЕМЕСТР 3\\практ3\\data.json')
server_address = ('127.0.0.1', 6379)
aggregator_url = 'http://127.0.0.1:5001/track'


class JSONCreator:
    def __init__(self, filename):
        self.filename = filename
        self.data = self.load_data()

    def load_data(self):
        try:
            with open(self.filename, 'r') as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def add_data(self, url, ip, time):
        if isinstance(time, datetime.datetime):
            time = time.strftime('%Y-%m-%d %H:%M:%S')
        data_entry = {"URL": url, "IP": ip, "Time": time}
        self.data.append(data_entry)

    def create_json(self):
        with open(self.filename, 'w') as file:
            json.dump(self.data, file)


def reduction(text):
    while True:
        try:
            short_link = "".join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for x in
                                 range(random.randrange(8, 9)))
            return short_link
        except:
            pass

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/track', methods=['POST'])
def track():
    with open(filename, 'r') as file:
        data = json.load(file)

    request_data = request.get_json()
    url = request_data['url']
    ip = request.remote_addr
    time = datetime.datetime.now()

    data.append({"URL": url, "IP": ip, "Time": time.strftime('%Y-%m-%d %H:%M:%S')})

    with open(filename, 'w') as file:
        json.dump(data, file)

    return 'OK'


def group_data(data, details_order):
    grouped_data = {}

    for detail in details_order:
        grouped_data[detail] = {}

    for entry in data:
        for detail in details_order:
            value = entry.get(detail)
            if value not in grouped_data[detail]:
                grouped_data[detail][value] = []

            grouped_data[detail][value].append(entry)

    return grouped_data


def generate_report_rows(report, grouped_data, details_order):
    for detail in details_order:
        json_creator = JSONCreator(filename)
        json_creator.create_json()
        report.add_row([detail.capitalize()])

        values = grouped_data[detail]
        for value, entries in values.items():
            report.add_row([value, len(entries)])

            if detail != details_order[-1]:
                sub_details_order = details_order[details_order.index(detail) + 1:]
                sub_grouped_data = group_data(entries, sub_details_order)
                generate_report_rows(report, sub_grouped_data, sub_details_order)


@app.route('/generate_report', methods=['POST'])
def generate_report():
    details_order = request.form.getlist('details_order[]')

    class Report:
        def __init__(self, details_order):
            self.details_order = details_order
            self.rows = []

        def add_row(self, values):
            self.rows.append(values)

        def generate_report(self):
            # Получаем данные переходов из файла или базы данных
            with open(filename, 'r') as file:
                data = json.load(file)

            # Группируем данные по выбранным детализациям
            grouped_data = group_data(data, self.details_order)

            # Генерируем отчет
            generate_report_rows(self, grouped_data, self.details_order)

    report = Report(details_order)
    report.generate_report()
    column_order = ["URL", "IP", "Time"]
    generate_html_report(filename, column_order, "otch.html")

    return 'Отчёт создан'


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5001, debug=True)
