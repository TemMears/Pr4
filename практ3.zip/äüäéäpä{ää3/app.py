import string

import requests
from flask import Flask, render_template, request, redirect
#from manager import generate_html_report
from urllib.parse import quote #для кодирования url
import socket
import random
import json
import datetime

# Сбор данных из первого сервиса
filename = "statistic.json"
column_order = ["URL", "IP", "Time"]
html_file = "test.html"

#generate_html_report(filename, column_order, html_file)
class JSONCreator:
    def __init__(self, filename):
        self.filename = filename
        self.data = self.load_data()

    def load_data(self):
        try:
            with open(self.filename, 'r') as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def add_data(self, original_url, ip, time):
        if isinstance(time, datetime.datetime):
            time = time.strftime('%Y-%m-%d %H:%M:%S')
        data_entry = {"URL": original_url, "IP": ip, "Time": time}
        self.data.append(data_entry)

    #def create_json(self):
      #  with open(self.filename, 'w') as file:
      #      json.dump(self.data, file)

    def save_data(self):
        with open(self.filename, 'w') as file:
            json.dump(self.data, file)

app = Flask(__name__)
server_address = ('127.0.0.1', 6379)
aggregator_url = 'http://127.0.0.1:5001/track'
json_creator = JSONCreator('data.json')

def reduction(text):
    while True:
        try:
            short_link = "".join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for x in range(random.randrange(8,9)))
            return short_link
        except:
            pass
#Метод POST предназначен для направления запроса, при котором веб-сервер принимает данные для хранения
#GET предназначен для получения информации от сервера
@app.route('/', methods = ['GET', 'POST'])
def index():
    generated_link = None
    if request.method == 'POST': #проверяем, был ли отправлен POST-запрос
        original_link = request.form['user_input']
        short_link = reduction(original_link)

        # Создает TCP-сокет с помощью модуля socket и присваивает его переменной s. Контекстный менеджер with автоматически закрывает сокет после использовани
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.connect(server_address) #устанавливает соединение с сервером
                s.sendall(f"PUSH!{short_link}!{original_link}\0".encode())
                print("Message sent successfully.")
                data = s.recv(1024) #Получаем ответ от сервера размером до 1024 байт
                print(f"Response from server: {data.decode()}")
            except ConnectionRefusedError:
                print("Connection to the server failed")
        generated_link = f"http://127.0.0.1:5000/{short_link}" #Формируем полную сгенерированную ссылку на основе короткой ссылки и адреса сервера
        json_creator.add_data(original_link + "(" + short_link+ ")", request.environ['REMOTE_ADDR'], datetime.datetime.now().replace(microsecond=0))
        json_creator.save_data()

    return render_template("index.html", output_link = generated_link)

@app.route('/<short_link>')
def redirect_to_original(short_link):
    # Получаем оригинальную ссылку из базы данных
    #Создает TCP-сокет с помощью модуля socket и присваивает его переменной s. Контекстный менеджер with автоматически закрывает сокет после использования
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect(server_address)
            s.sendall(f"HGET!{short_link}\0".encode())
            data = s.recv(1024)
            original_link = data.decode()
        except ConnectionRefusedError:
            print("Connection to the server failed.")
            return "Internal Server Error"

    # Открытие оригинальной ссылки

    if original_link != "error":
        json_creator = JSONCreator('statistic.json')
        return redirect(original_link)
    else:
        return render_template('notindex.html')

if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=True) #Запускает веб-приложение на локальном хосте (127.0.0.1) и порту 5000 в режиме отладки (debug=True).